﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","da",{title:"Brugerflade på farvevælger",preview:"Vis liveeksempel",config:"Indsæt denne streng i din config.js fil",predefined:"Prædefinerede farveskemaer"});